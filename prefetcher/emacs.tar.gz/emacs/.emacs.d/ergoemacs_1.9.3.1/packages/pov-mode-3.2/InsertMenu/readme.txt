The content of this package has been created from the 
POV-Ray 3.6 insert menu that is included with the Windows 
and Mac versions of POV-Ray.

This package is provided to simplify access to the insert 
menu without the need to obtain and extract the Windows 
binary package.  It is covered by the POV-Ray license and
may be used by anyone eligible to use POV-Ray according to 
this license.

