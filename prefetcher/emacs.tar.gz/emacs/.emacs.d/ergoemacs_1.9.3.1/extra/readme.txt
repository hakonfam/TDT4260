; -*- coding: utf-8 -*-

2010-06-15

files in this directory are some key config files to make bash, X11, or Mac OS X or Windows to use ErgoEmacs keybinding. (as much as possible)

for detail, see:

• System-wide ErgoEmacs Keybinding for Windows, Mac, Bash
  http://xahlee.org/emacs/ergonomic_emacs_keybinding_system-wide.html