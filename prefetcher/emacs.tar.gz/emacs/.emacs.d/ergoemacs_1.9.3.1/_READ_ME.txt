-*- coding: utf-8 -*-

This is the source code for ErgoEmacs project.

The project's home page is at http://ergoemacs.org/

The project's home page for developers is at http://code.google.com/p/ergoemacs/

For version history for developers, see: _VERSION_HISTORY.txt

For building a Windows binary release, see: http://code.google.com/p/ergoemacs/wiki/CreatingErgoEmacsWindowsInstaller

For building a the ErgoEmacs Package that can be installed on any emacs binary, see: build-util/build_ergoemacs_package.el

The installation instructions of ErgoEmacs Package is at _PACKAGE_INSTALL_INSTRUCTION.txt
